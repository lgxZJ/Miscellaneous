window.parent.document.getElementById('content-iframe').width = '1000px';
window.parent.document.getElementById('content-iframe').height = '500px';